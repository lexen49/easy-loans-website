const amount = document.getElementById('amount');
const rate = document.getElementById('rate');
const months = document.getElementById('months');

function money(value) {
  return 'KES ' + Math.round(value).toLocaleString('en-KE');
}

function updateEstimate() {
  const principal = Math.max(0, Number(amount.value) || 0);
  const annualRate = Math.max(0, Number(rate.value) || 0) / 100;
  const period = Math.max(1, Number(months.value) || 1);
  const monthlyRate = annualRate / 12;
  const payment = monthlyRate === 0
    ? principal / period
    : principal * monthlyRate / (1 - Math.pow(1 + monthlyRate, -period));
  const total = payment * period;

  document.getElementById('monthly').textContent = money(payment);
  document.getElementById('total').textContent = money(total);
  document.getElementById('interest').textContent = money(total - principal);
}

[amount, rate, months].forEach(field => field.addEventListener('input', updateEstimate));
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('enquiry-form').addEventListener('submit', event => {
  event.preventDefault();
  document.getElementById('form-message').textContent =
    'Demo only: your enquiry has not been sent or stored. Connect a secure, consent-based service before accepting real applications.';
});
updateEstimate();
