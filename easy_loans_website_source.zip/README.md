# Easy Loans demo website

## Files
- `index.html` — website content
- `styles.css` — page design
- `script.js` — sample repayment calculator and demo enquiry response

## Deploy on Render
1. Upload these four files individually to the top level (root) of your GitHub repository.
2. In Render, create or update a **Static Site** connected to that repository.
3. Set the branch to `main`.
4. Leave the Build Command blank.
5. Set Publish Directory to `.` (a single dot).
6. Deploy. The repository root must contain `index.html`.

## Important safety note
This is a front-end demonstration. The enquiry form does not send or store personal information. Do not collect M-Pesa PINs, bank PINs, passwords, or one-time verification codes. Before accepting real applications, use a lawful, secure backend, publish clear lender identity and terms, and obtain appropriate consent.
