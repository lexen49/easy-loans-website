const amount = document.getElementById('amount');
const amountValue = document.getElementById('amountValue');
const term = document.getElementById('term');
const rate = document.getElementById('rate');
const monthly = document.getElementById('monthly');
const interest = document.getElementById('interest');
const total = document.getElementById('total');
const requestedAmount = document.getElementById('requestedAmount');

const kes = value => new Intl.NumberFormat('en-KE', {
  style: 'currency', currency: 'KES', maximumFractionDigits: 0
}).format(value);

function updateCalculator() {
  const principal = Number(amount.value);
  const months = Math.max(1, Number(term.value));
  const monthlyRate = Math.max(0, Math.min(30, Number(rate.value) || 0)) / 100;
  const interestTotal = principal * monthlyRate * months;
  const repaymentTotal = principal + interestTotal;
  amountValue.textContent = kes(principal);
  monthly.textContent = kes(repaymentTotal / months);
  interest.textContent = kes(interestTotal);
  total.textContent = kes(repaymentTotal);
  requestedAmount.value = principal;
}
[amount, term, rate].forEach(control => control.addEventListener('input', updateCalculator));
document.getElementById('year').textContent = new Date().getFullYear();
updateCalculator();

document.getElementById('applicationForm').addEventListener('submit', event => {
  event.preventDefault();
  const status = document.getElementById('formStatus');
  if (!event.currentTarget.reportValidity()) return;
  status.textContent = 'Demo only: your information has not been sent or saved. Connect a secure application service before going live.';
  event.currentTarget.reset();
});
