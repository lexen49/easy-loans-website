# Easy Loans — website starter

This is an original, mobile-friendly front-end starter inspired by a modern loan enquiry website. It is not a copy of another site's private source code.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive styling
- `script.js` — calculator and demo form behavior

## Preview on a computer
Open `index.html` in a browser.

## Deploy on Render (static site)
1. Create a GitHub repository and upload these files.
2. In Render, choose **New +** → **Static Site**.
3. Connect your repository.
4. Leave **Build Command** blank.
5. Set **Publish Directory** to `.` (a single dot).
6. Deploy.

## Before accepting real applications
The form is deliberately in demo mode: it does not send or store customer information. Before launch, connect it to a secure backend and:
- publish the lender's true legal/business identity and contact details;
- show complete, accurate interest, fee, repayment and privacy terms;
- use HTTPS and appropriate data protection controls;
- never request or store mobile-money PINs, passwords, OTPs or private SMS messages;
- never imply affiliation with MTN or another provider unless formally authorized.

The calculator uses a simple flat-rate illustration. It is not a quote, approval or financial advice.
